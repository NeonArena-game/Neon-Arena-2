/*
 * NEON ARENA 2 — DROP UPDATE #2
 * v1.0.0
 * Conteúdo oficial integrado ao jogo base.
 *
 * Foco: nova identidade visual em SVG.
 * - 2 logos oficiais reutilizáveis
 * - ícone do Drop #2
 * - Spark + badge SVG
 * - Galeria de logos no menu
 * - pequena marca visual do Drop #2
 */
(function () {
    'use strict';

    const VERSION = '1.0.0';
    const state = { scene: null, badge: null, logo: null, gallery: null, opened: false };

    function destroy(obj) { try { if (obj && obj.active) obj.destroy(); } catch (_) {} }

    function logoSize(scene) {
        const w = Math.max(260, Math.min(430, scene.scale.width * 0.34));
        return { w, h: w * 150 / 520 };
    }

    function addMenuLogo(scene) {
        if (!scene || scene.scale.width < 420 || !scene.textures.exists('na_logo_02')) return;
        if (state.logo && state.logo.scene) return;

        const oldTitle = (scene.children.list || []).find(o => o && o.type === 'Text' && o.text === 'NEON ARENA 2');
        if (oldTitle) oldTitle.setVisible(false);

        const size = logoSize(scene);
        state.logo = scene.add.image(scene.scale.width / 2, Math.max(64, scene.scale.height / 4 - 150), 'na_logo_02')
            .setDisplaySize(size.w, size.h)
            .setOrigin(0.5)
            .setDepth(20);

        if (window.neonAnimationsEnabled ? window.neonAnimationsEnabled() : true) {
            state.logo.setAlpha(0);
            scene.tweens.add({ targets: state.logo, alpha: 1, duration: 450, ease: 'Quad.easeOut' });
        }
    }

    function showGallery(scene) {
        if (!scene || state.gallery) return;
        state.opened = true;
        localStorage.setItem('neon_drop2_logo_seen', 'true');
        if (typeof showNotification === 'function') showNotification(scene, '✨ GALERIA DE LOGOS\nDrop #2 desbloqueou a nova identidade visual.', 'success');

        const W = Math.min(760, scene.scale.width - 30);
        const H = Math.min(520, scene.scale.height - 30);
        const cx = scene.scale.width / 2, cy = scene.scale.height / 2;
        const els = [];
        const bg = scene.add.rectangle(cx, cy, W, H, 0x050814, 0.97).setStrokeStyle(2, 0x00f6ff, 0.8).setDepth(9000);
        const title = scene.add.text(cx, cy - H / 2 + 34, '✦ DROP #2 — LOGO VAULT', { fontSize: '25px', color: '#00f6ff', fontStyle: 'bold' }).setOrigin(0.5).setDepth(9001);
        const sub = scene.add.text(cx, cy - H / 2 + 68, 'As duas marcas SVG são assets oficiais e reutilizáveis em versões futuras.', { fontSize: '12px', color: '#bfefff', align: 'center', wordWrap: { width: W - 60 } }).setOrigin(0.5).setDepth(9001);
        els.push(bg, title, sub);

        const left = scene.add.image(cx - W * 0.24, cy - 5, 'na_logo_01').setDisplaySize(Math.min(290, W * .38), Math.min(90, H * .24)).setDepth(9001);
        const right = scene.add.image(cx + W * 0.24, cy - 5, 'na_logo_02').setDisplaySize(Math.min(330, W * .43), Math.min(96, H * .25)).setDepth(9001);
        const l1 = scene.add.text(cx - W * 0.24, cy + 78, 'LOGO 01 • MASTER', { fontSize: '13px', color: '#00f6ff' }).setOrigin(0.5).setDepth(9001);
        const l2 = scene.add.text(cx + W * 0.24, cy + 78, 'LOGO 02 • VERSIONADA', { fontSize: '13px', color: '#ff3bf2' }).setOrigin(0.5).setDepth(9001);
        els.push(left, right, l1, l2);

        const info = scene.add.text(cx, cy + H / 2 - 82, '01 = marca base\n02 = marca com numeração da versão\n\nO número pode mudar em versões futuras sem abandonar a identidade.', { fontSize: '14px', color: '#fff', align: 'center', lineSpacing: 6 }).setOrigin(0.5).setDepth(9001);
        const close = scene.add.text(cx, cy + H / 2 - 28, 'FECHAR', { fontSize: '17px', backgroundColor: '#15243a', color: '#fff', padding: { left: 14, right: 14, top: 8, bottom: 8 } }).setOrigin(0.5).setInteractive().setDepth(9002);
        els.push(info, close);
        close.on('pointerdown', () => { els.forEach(destroy); state.gallery = null; });
        state.gallery = { destroy: () => { els.forEach(destroy); state.gallery = null; } };
    }

    function addDropBadge(scene) {
        if (!scene || state.badge || scene.scale.width < 420 || !scene.textures.exists('drop2_badge')) return;
        const badge = scene.add.image(28, 28, 'drop2_badge').setDisplaySize(38, 38).setOrigin(0.5).setDepth(30).setInteractive({ useHandCursor: true });
        const label = scene.add.text(54, 28, 'DROP #2', { fontSize: '13px', color: '#00f6ff', fontStyle: 'bold', backgroundColor: '#071018', padding: { left: 7, right: 7, top: 5, bottom: 5 } }).setOrigin(0, 0.5).setDepth(30).setInteractive();
        const hit = () => showGallery(scene);
        badge.on('pointerdown', hit); label.on('pointerdown', hit);
        state.badge = { badge, label };
    }

    function addGameMark(scene) {
        // Keep the in-game mark tiny and away from the main HUD.
        if (!scene || !isPlaying || !scene.textures.exists('na_logo_01')) return;
        if (scene.__drop2GameMark) return;
        const mark = scene.add.image(scene.scale.width - 18, scene.scale.height - 18, 'na_logo_01')
            .setDisplaySize(105, 30).setOrigin(1, 1).setAlpha(0.38).setDepth(2).setScrollFactor(0);
        scene.__drop2GameMark = mark;
    }

    function create(scene) {
        if (state.scene !== scene) {
            state.logo = null;
            state.badge = null;
            state.gallery = null;
        }
        state.scene = scene;
        if (!isPlaying) {
            setTimeout(() => {
                if (!scene.sys || !scene.sys.isActive || !scene.sys.isActive()) return;
                addMenuLogo(scene);
                addDropBadge(scene);
            }, 20);
        } else {
            addGameMark(scene);
        }
    }

    function update(scene) {
        if (!scene || !scene.sys || !scene.sys.isActive || !scene.sys.isActive()) return;
        if (state.gallery && isPlaying) state.gallery.destroy();
        if (!isPlaying) {
            if (!state.logo || !state.logo.scene) addMenuLogo(scene);
            if (!state.badge) addDropBadge(scene);
        } else {
            addGameMark(scene);
        }
    }

    function shutdown() {
        if (state.gallery) state.gallery.destroy();
        state.gallery = null;
        state.logo = null;
        state.badge = null;
        state.scene = null;
    }

    if (window.NeonArena2Builtin) {
        window.NeonArena2Builtin.register('Drop Update #2 [BUILT-IN] v' + VERSION, {
            afterGameStart: create,
            sceneCreate: create,
            sceneUpdate: update
        });
        console.log('[Neon Arena 2][Official Update] Drop Update #2 v' + VERSION + ' integrado.');
    }
})();
