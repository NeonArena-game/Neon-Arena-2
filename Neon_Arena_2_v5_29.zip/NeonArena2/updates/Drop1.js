/*
 * NEON ARENA 2 — DROP UPDATE #1
 * v1.0.0
 * Conteúdo oficial integrado ao jogo base a partir do Drop #2.
 *
 * Conteúdo:
 * - Novo inimigo: Dropper
 * - Nova mecânica: Drop Fever (5 kills rápidos)
 * - Novo power-up: Drop Core
 * - 2 conquistas
 * - efeitos visuais + sons Web Audio
 * - segredo DROP//NULL
 * - ícones SVG
 */
(function () {
    'use strict';

    const MOD_NAME = 'Drop Update #1';
    const MOD_VERSION = '1.0.0';
    const PREFIX = 'neon_drop1_';

    const state = {
        scene: null,
        pickupGroup: null,
        nextCoreAt: 0,
        nextEnemyAt: 0,
        nextSecretAt: 0,
        feverUntil: 0,
        killStreak: 0,
        lastKillCount: Number(localStorage.getItem('neon_total_kills') || 0),
        streakDeadline: 0,
        cores: Number(localStorage.getItem(PREFIX + 'cores') || 0),
        secretShown: localStorage.getItem(PREFIX + 'secret') === 'true',
        setupDone: false,
        panel: null,
        audioContext: null,
        lastPulse: 0
    };

    function R() {
        return window.NeonArena2Runtime || {
            game: null, player1: null, player2: null, enemies: null, enemyBullets: null,
            hitEnemy: null, isPlaying: false, isGameOver: false, isPaused: false
        };
    }

    const ICONS = {
        drop: 'assets/svg/drop1/drop.svg',
        enemy: 'assets/svg/drop1/dropper.svg',
        core: 'assets/svg/drop1/core.svg',
        secret: 'assets/svg/drop1/secret.svg'
    };

    function now(scene) {
        return scene && scene.time ? scene.time.now : performance.now();
    }

    function safeScene(scene) {
        if (scene && scene.sys && scene.add && scene.physics) return scene;
        if (R().game && R().game.scene && R().game.scene.scenes) {
            return R().game.scene.scenes.find(s => s && s.sys && s.sys.isActive && s.sys.isActive()) || null;
        }
        return null;
    }

    function save() {
        localStorage.setItem(PREFIX + 'cores', String(state.cores));
    }

    function notify(scene, text, type) {
        try {
            if (typeof showNotification === 'function') showNotification(scene, String(text), type || 'info');
        } catch (_) {}
    }

    function sound(type) {
        try {
            const Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return;
            if (!state.audioContext) state.audioContext = new Ctx();
            const ctx = state.audioContext;
            if (ctx.state === 'suspended') ctx.resume().catch(() => {});
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            const t = ctx.currentTime;
            const sets = {
                core: [520, 880, 0.13],
                enemy: [170, 90, 0.16],
                fever: [330, 660, 0.22],
                secret: [740, 1480, 0.35],
                achievement: [440, 990, 0.25]
            };
            const s = sets[type] || [400, 500, 0.12];
            osc.type = type === 'enemy' ? 'sawtooth' : 'sine';
            osc.frequency.setValueAtTime(s[0], t);
            osc.frequency.exponentialRampToValueAtTime(Math.max(50, s[1]), t + s[2]);
            gain.gain.setValueAtTime(0.0001, t);
            gain.gain.exponentialRampToValueAtTime(0.08, t + 0.015);
            gain.gain.exponentialRampToValueAtTime(0.0001, t + s[2]);
            osc.connect(gain).connect(ctx.destination);
            osc.start(t);
            osc.stop(t + s[2] + 0.02);
        } catch (_) {}
    }

    function addTextureFromSVG(scene, key, svg) {
        if (!scene || !scene.textures || scene.textures.exists(key)) return;
        try {
            const uri = 'data:image/svg+xml;base64,' + btoa(svg);
            scene.textures.addBase64(key, uri);
        } catch (error) {
            console.warn('[Drop #1] Falha ao registrar SVG:', key, error);
        }
    }

    const SVG = {
        enemy: `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect x="5" y="5" width="22" height="22" rx="5" fill="#090b18" stroke="#ff3bf2" stroke-width="2"/><path d="M16 8v16M8 16h16" stroke="#00f6ff" stroke-width="2"/><circle cx="16" cy="16" r="4" fill="#ff3bf2"/><circle cx="16" cy="16" r="1.5" fill="#fff"/></svg>`,
        bullet: `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="4" fill="#ff3bf2" stroke="#fff" stroke-width="1"/><circle cx="6" cy="6" r="1.5" fill="#00f6ff"/></svg>`,
        core: `<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26"><path d="M13 2l9 5v12l-9 5-9-5V7z" fill="#101426" stroke="#00f6ff" stroke-width="2"/><path d="M13 6l5 3v7l-5 3-5-3V9z" fill="#00f6ff" opacity=".32"/><path d="M13 7v12M7 10l6 3 6-3" fill="none" stroke="#fff" stroke-width="1.4"/></svg>`
    };

    function flash(scene, x, y, color, radius) {
        if (!scene || !scene.add) return;
        const r = scene.add.circle(x, y, radius || 22, color || 0x00f6ff, 0.22).setDepth(350);
        const ring = scene.add.circle(x, y, 8, color || 0x00f6ff, 0).setStrokeStyle(3, color || 0x00f6ff, 0.9).setDepth(351);
        scene.tweens.add({
            targets: [r, ring],
            radius: radius ? radius * 2.2 : 50,
            alpha: 0,
            duration: 360,
            ease: 'Quad.easeOut',
            onComplete: () => { if (r.active) r.destroy(); if (ring.active) ring.destroy(); }
        });
    }

    function floatingText(scene, text, x, y, color) {
        if (!scene || !scene.add) return;
        const t = scene.add.text(x, y, text, {
            fontSize: '18px',
            fontStyle: 'bold',
            color: color || '#00f6ff',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5).setDepth(352);
        scene.tweens.add({
            targets: t, y: y - 42, alpha: 0, duration: 900,
            ease: 'Cubic.easeOut', onComplete: () => { if (t.active) t.destroy(); }
        });
    }

    function unlockAchievement(scene, id, title, description) {
        const key = PREFIX + 'ach_' + id;
        if (localStorage.getItem(key) === 'true') return false;
        localStorage.setItem(key, 'true');
        sound('achievement');
        notify(scene, `🏆 CONQUISTA!\n${title}\n${description}`, 'achievement');
        return true;
    }

    function createPanel() {
        if (state.panel) state.panel.remove();
        const panel = document.createElement('div');
        panel.id = 'neon-drop1-panel';
        panel.style.cssText = [
            'position:fixed',
            'left:12px',
            'bottom:12px',
            'z-index:99999',
            'display:flex',
            'align-items:center',
            'gap:8px',
            'padding:7px 10px',
            'border:1px solid rgba(0,246,255,.65)',
            'border-radius:8px',
            'background:rgba(5,8,20,.86)',
            'box-shadow:0 0 14px rgba(0,246,255,.22)',
            'color:#fff',
            'font:600 12px Arial,sans-serif',
            'pointer-events:none',
            'user-select:none'
        ].join(';');

        const img = document.createElement('img');
        img.src = ICONS.drop;
        img.width = 22;
        img.height = 22;
        img.alt = 'Drop #1';
        img.style.cssText = 'display:block;filter:drop-shadow(0 0 4px #00f6ff)';

        const text = document.createElement('span');
        text.textContent = 'DROP #1 • 0 CORES';
        text.id = 'neon-drop1-panel-text';

        panel.appendChild(img);
        panel.appendChild(text);
        document.body.appendChild(panel);
        state.panel = panel;
        updatePanel();
    }

    function updatePanel() {
        const el = document.getElementById('neon-drop1-panel-text');
        if (el) el.textContent = `DROP #1 • ${state.cores} ${state.cores === 1 ? 'CORE' : 'CORES'}`;
    }

    function spawnCore(scene) {
        if (!state.pickupGroup || !scene || !R().player1) return;
        const margin = 70;
        const x = Phaser.Math.Between(margin, Math.max(margin, scene.scale.width - margin));
        const y = Phaser.Math.Between(margin, Math.max(margin, scene.scale.height - margin));
        const core = state.pickupGroup.create(x, y, 'drop1_core');
        core.setData('drop1Core', true);
        core.setDepth(6);
        core.setScale(0.95);
        core.body.setAllowGravity(false);
        core.body.setCircle(11);
        core.body.setVelocity(0, 0);
        scene.tweens.add({
            targets: core,
            scale: 1.18,
            angle: 360,
            duration: 900,
            yoyo: true,
            repeat: -1
        });
        flash(scene, x, y, 0x00f6ff, 14);
    }

    function collectCore(scene, player, core) {
        if (!core || !core.active || !core.getData('drop1Core')) return;
        core.destroy();
        state.cores++;
        save();
        updatePanel();
        sound('core');
        flash(scene, player.x, player.y, 0x00f6ff, 25);
        floatingText(scene, '+ DROP CORE', player.x, player.y - 20, '#00f6ff');

        if (state.cores === 1) {
            unlockAchievement(scene, 'first', 'PRIMEIRA QUEDA', 'Colete seu primeiro Drop Core.');
        }
        if (state.cores >= 5) {
            unlockAchievement(scene, 'hunter', 'CAÇADOR DE DROPS', 'Colete 5 Drop Cores.');
        }

        // Power-up: pulso de impacto que enfraquece todos os inimigos.
        if (R().enemies && R().hitEnemy) {
            R().enemies.getChildren().forEach(e => {
                if (!e || !e.active || e.getData('defeated')) return;
                try {
                    R().hitEnemy.call(scene, null, e, { overrideDamage: 1, swordHit: true });
                } catch (_) {
                    const hp = Number(e.health) || 1;
                    e.health = Math.max(0, hp - 1);
                }
            });
        } else if (state.scene && state.scene.children) {
            // Fallback para ambientes em que os bindings não são expostos ao window.
            console.log('[Neon Arena 2][Drop #1] Drop Core coletado; pulso visual ativado.');
        }

        const all = scene.children.list || [];
        all.forEach(obj => {
            if (obj && obj.active && obj.getData && obj.getData('drop1Core')) return;
        });
        notify(scene, '💠 DROP CORE!\nPulso liberado: inimigos receberam dano.', 'success');
    }

    function spawnDropper(scene) {
        if (!scene || !scene.physics || !scene.add) return;
        if (!R().enemies || !R().enemies.create) return;
        if (R().enemies.countActive(true) >= 42) return;

        const x = Math.random() < 0.5 ? -60 : scene.scale.width + 60;
        const y = Phaser.Math.Between(60, Math.max(60, scene.scale.height - 60));
        const e = R().enemies.create(x, y, 'drop1_enemy');
        e.health = 3;
        e.setData('maxHealth', 3);
        e.setData('aiRole', 'drop1_dropper');
        e.setData('drop1Enemy', true);
        e.setData('defeated', false);
        e.setActive(true).setVisible(true);
        e.setDepth(5);
        e.setScale(1.0);
        sound('enemy');
        flash(scene, x, y, 0xff3bf2, 18);
        notify(scene, '⚠️ DROPper entrou na arena!', 'warning');
    }

    function updateDroppers(scene, time) {
        if (!R().enemies || !scene || !R().player1) return;
        const target = R().player1;
        R().enemies.getChildren().forEach(e => {
            if (!e || !e.active || !e.getData('drop1Enemy')) return;

            if (state.feverUntil > time) {
                e.setTint(0xffff66);
            } else {
                e.clearTint();
            }

            const dist = Phaser.Math.Distance.Between(e.x, e.y, target.x, target.y);
            const angle = Phaser.Math.Angle.Between(e.x, e.y, target.x, target.y);
            const orbit = angle + Math.sin(time * 0.003 + e.x * 0.01) * 0.65;
            const desiredSpeed = dist > 360 ? 135 : (dist < 250 ? -110 : 85);
            e.setVelocity(Math.cos(orbit) * desiredSpeed, Math.sin(orbit) * desiredSpeed);

            if (!e.nextDrop1Shot) e.nextDrop1Shot = time + 700;
            if (time >= e.nextDrop1Shot && R().enemyBullets && R().enemyBullets.countActive(true) < 65) {
                const b = R().enemyBullets.create(e.x, e.y, 'drop1_bullet');
                b.setData('sourceEnemy', e);
                b.setData('enemyDamage', 1);
                b.setData('drop1Bullet', true);
                b.setDepth(4);
                const aim = Phaser.Math.Angle.Between(e.x, e.y, target.x, target.y);
                const spread = (Math.random() - 0.5) * 0.16;
                scene.physics.velocityFromRotation(aim + spread, state.feverUntil > time ? 520 : 430, b.body.velocity);
                e.nextDrop1Shot = time + (state.feverUntil > time ? 1050 : 1650);
            }
        });
    }

    function detectKills(scene, time) {
        const current = Number(localStorage.getItem('neon_total_kills') || 0);
        if (current > state.lastKillCount) {
            const gained = Math.min(20, current - state.lastKillCount);
            state.lastKillCount = current;
            state.killStreak += gained;
            state.streakDeadline = time + 7000;
            if (state.killStreak >= 5) {
                state.killStreak = 0;
                state.feverUntil = time + 6000;
                sound('fever');
                notify(scene, '🔥 DROP FEVER!\n5 eliminações rápidas ativaram o Drop Surge!', 'achievement');
                flash(scene, scene.scale.width / 2, scene.scale.height / 2, 0xff3bf2, 80);
            }
        }
        if (state.killStreak > 0 && time > state.streakDeadline) state.killStreak = 0;
    }

    function secretSignal(scene, time) {
        if (state.secretShown || !scene || time < state.nextSecretAt) return;
        if (Math.random() > 0.012) {
            state.nextSecretAt = time + 900;
            return;
        }
        state.secretShown = true;
        localStorage.setItem(PREFIX + 'secret', 'true');
        sound('secret');
        flash(scene, scene.scale.width / 2, scene.scale.height / 2, 0x9b5cff, 90);

        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;pointer-events:none;font:900 30px Arial,sans-serif;color:#fff;text-shadow:0 0 10px #9b5cff,0 0 25px #00f6ff';
        wrap.innerHTML = `<img src="${ICONS.secret}" width="38" height="38" style="margin-right:12px"><span>DROP//NULL</span>`;
        document.body.appendChild(wrap);
        setTimeout(() => wrap.remove(), 1500);
        notify(scene, '🔐 SEGREDO ENCONTRADO!\nDROP//NULL', 'achievement');
    }

    function setupScene(scene) {
        scene = safeScene(scene);
        if (!scene || state.scene === scene && state.setupDone) return;
        state.scene = scene;
        state.setupDone = true;

        if (scene.textures) {
            addTextureFromSVG(scene, 'drop1_enemy', SVG.enemy);
            addTextureFromSVG(scene, 'drop1_bullet', SVG.bullet);
            addTextureFromSVG(scene, 'drop1_core', SVG.core);
        }

        setTimeout(() => {
            if (!scene.sys || !scene.sys.isActive || !scene.sys.isActive() || !scene.physics) return;
            if (!state.pickupGroup || !state.pickupGroup.scene) {
                state.pickupGroup = scene.physics.add.group();
            }

            if (R().player1 && !scene.__drop1Overlaps) {
                scene.__drop1Overlaps = true;
                scene.physics.add.overlap(R().player1, state.pickupGroup, (p, c) => collectCore(scene, p, c), null, scene);
                if (R().player2) {
                    scene.physics.add.overlap(R().player2, state.pickupGroup, (p, c) => collectCore(scene, p, c), null, scene);
                }
            }

            state.nextCoreAt = scene.time.now + 7000;
            state.nextEnemyAt = scene.time.now + 9000;
            state.nextSecretAt = scene.time.now + 6000;
            createPanel();
        }, 0);

        scene.events.once('shutdown', () => {
            if (state.panel) {
                state.panel.remove();
                state.panel = null;
            }
            state.pickupGroup = null;
            state.setupDone = false;
        });
    }

    function update(scene, time) {
        scene = safeScene(scene);
        if (!scene || !scene.time) return;
        if (!state.setupDone) setupScene(scene);

        if (!R().isPlaying || R().isGameOver || R().isPaused) return;

        if (time >= state.nextCoreAt) {
            spawnCore(scene);
            state.nextCoreAt = time + (state.feverUntil > time ? 9000 : 14000);
        }

        if (time >= state.nextEnemyAt) {
            spawnDropper(scene);
            state.nextEnemyAt = time + (state.feverUntil > time ? 8500 : 18000);
        }

        detectKills(scene, time);
        updateDroppers(scene, time);
        secretSignal(scene, time);

        if (state.feverUntil > time && time - state.lastPulse > 700) {
            state.lastPulse = time;
            flash(scene, scene.scale.width / 2, scene.scale.height / 2, 0xff3bf2, 45);
        }
    }

    function afterStart(scene) {
        setupScene(scene);
        // Exposição opcional para debug/integrações.
        window.NeonArena2Drop1 = {
            name: MOD_NAME,
            version: MOD_VERSION,
            state,
            getCores: () => state.cores,
            isFeverActive: () => state.feverUntil > (state.scene ? state.scene.time.now : performance.now()),
            spawnCore: () => spawnCore(safeScene()),
            spawnDropper: () => spawnDropper(safeScene())
        };
    }

    if (window.NeonArena2Builtin) {
        window.NeonArena2Builtin.register(MOD_NAME + ' [BUILT-IN]', {
            afterGameStart: afterStart,
            sceneCreate: setupScene,
            sceneUpdate: update
        });
        console.log('[Neon Arena 2][Official Update] ' + MOD_NAME + ' v' + MOD_VERSION + ' integrado ao jogo base.');
    } else {
        console.error('[Drop #1] Sistema de updates oficiais não encontrado.');
    }
})();
